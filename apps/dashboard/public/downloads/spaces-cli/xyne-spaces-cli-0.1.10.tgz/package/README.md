# @xyne/spaces-cli

The **`spaces`** command — scaffold, run, and publish Xyne Spaces apps from the terminal.

> macOS only for now (it reads your browser's Spaces session from the system keychain + cookie store).

## Install

```bash
npm install -g @xyne/spaces-cli
spaces help
```

## Quick start

```bash
spaces app init my-app       # scaffold Vite + React + TS + Tailwind + shadcn/ui
cd my-app
spaces token                 # fill .env from the browser you're signed into
npm run dev                  # build your UI (the badge bottom-right switches surfaces)
spaces app publish           # create the app and make it workspace-visible
```

## Commands

Resource-first (`spaces <resource> <command>`). Run `spaces <command> --help` for a command's flags.

**Apps**
| command | what it does |
|---|---|
| `spaces app init [<dir>]` | scaffold an app (current dir or a new folder) |
| `spaces app push` | create the app (first push) or add a version |
| `spaces app publish` | push and make the app workspace-visible |
| `spaces app unpublish` | make a published app private again |
| `spaces app versions` | list an app's versions (head / published marked) |
| `spaces app restore <v>` | move HEAD back to a version (reversible) |
| `spaces app list [--workspace]` | list your apps (or the workspace's published ones) |
| `spaces app pull <appId>` | download an app's files into a folder |

**Auth**
| command | what it does |
|---|---|
| `spaces token` | write a Spaces token into `.env` (no-op if still valid) |

**Config**
| command | what it does |
|---|---|
| `spaces config set url <host>` | set the server the CLI talks to |
| `spaces config get [url]` | show a setting (or all of them) and where it came from |

## Building for different surfaces

One published app can be opened from several places in Spaces, and each gives it a different amount of room. The app is told which one it's in, so a single build can lay itself out for each.

| `surface` | Where the app is open | `layout` | Extra fields |
|---|---|---|---|
| `toolbar` | The left rail. The app has the whole screen. | `fullscreen` | — |
| `inbox` | The Inbox menubar, inside the chat panel, next to the channel list | `panel` | — |
| `channel` | A tab in a channel's navbar, next to Messages / Files / Pins | `panel` | `channel: { id, name, scopeType }` |
| `library` | Agent Hub → Apps → the app's own page | `fullscreen` | — |
| `chat` | Not a bar: an artifact shown inside a conversation or its expand dialog | `fullscreen` | — |
| `standalone` | No host at all (`npm run dev`, before you pick a surface) | `fullscreen` | — |

### Reading the context

Every scaffold includes `lib/xyne-context.ts`:

```tsx
import { useXyneContext } from './lib/xyne-context';

export default function App() {
  const ctx = useXyneContext();           // null until known
  if (!ctx) return <Skeleton />;

  switch (ctx.surface) {
    case 'channel': return <ChannelView channelId={ctx.channel.id} />;
    case 'inbox':   return <CompactDigest />;
    default:        return <FullDashboard />;
  }
}
```

- **`useXyneContext()`** returns the context, or `null` until it's known. A published app gets the value just after first paint, so show a skeleton for `null` rather than guessing a surface. A wrong guess makes the layout jump.
- **`ctx.channel` only exists when `surface === 'channel'`**, so checking the surface first narrows the type. You don't need optional chaining.
- **`ctx.layout`** is `'fullscreen'` or `'panel'`. Use it to choose a layout (a dense list or a full board, say), and still use CSS for widths.
- **`ctx.appId`** and **`ctx.workspaceId`** are there when the host has them.
- Outside React, use **`getXyneContext()`** (a promise that resolves once the context is known) and **`onXyneContext(cb)`** (subscribe to changes; returns an unsubscribe function).

The context can change while the app is running. If a user keeps your channel tab open and moves to another channel, the host sends the new channel and the hook re-renders. Key your effects on `ctx.channel.id` and the app follows them:

```tsx
const channelId = ctx?.surface === 'channel' ? ctx.channel.id : null;
useEffect(() => {
  if (channelId) void load(channelId);
}, [channelId]);
```

Handle a `surface` value you don't recognise as the general case. Spaces may add new places to open apps after your app ships.

> **Context is not a permission.** Your app can't fake it, but `channel.id` only tells you where the app was opened, not what the viewer is allowed to read. Every SDK call still runs as the viewer and is checked on the server. Don't show or hide data based on the context alone.

### The channel surface

Channel tabs exist only in real channels (public or private), never in DMs or group DMs, so `channel.scopeType` is always `'DEFAULT'`. The layout is always `panel`, so design for a narrow column of about 400px.

The channel id works with the channel-scoped SDK calls: `channels.getStats`, `listParticipants`, `getUserStatus` (is this viewer a member?), `listLinks`; `conversations.listByChannel`, `listPinned`; `messages.listByChannel`, `getLatestInChannel`, `listChannelAttachments`; `search.query({ q, in: channelId })`.

App storage is shared across the whole app, not per channel. To keep settings per channel, key them yourself:

```ts
await storage.collection('prefs').put(ctx.channel.id, { range: '30d' });
```

The context does **not** include the open thread, a selected message, or the viewer's role in the channel (fetch that with `channels.getUserStatus`). It also gives you no way to navigate the host.

### Switching surfaces while you develop

`npm run dev` has no host to answer "where am I?", so the local `lib/xyne-context.ts` answers instead and draws a **switcher badge in the bottom-right corner**. It shows the current surface (for example `⚙ channel · design-review`). Click it to open the panel:

- **Surface**: pick `toolbar`, `inbox`, `channel`, `library` or `standalone`. The app re-renders straight away with no reload, so its state stays put while you compare layouts.
- **Channel** (shown when `channel` is picked): your real channels, loaded with the token in `.env`, so you pick by name and the app gets a real id. Run `spaces token` first. If the list can't load, a field lets you paste an id instead.
- **Preview → panel width**: narrows the page to 420px, roughly the real width of the Inbox and channel panels. It turns on automatically when you pick a panel surface. It only changes the preview, never what the app receives.
- **Preview → delay first answer**: holds the context back for about 600ms so you can see your `null` / loading state locally.

You can also switch without the badge:

```text
http://localhost:5173/?xyne_surface=channel&xyne_channel=<channelId>
```

```js
__xyne.setSurface('inbox');                  // from the devtools console
__xyne.setSurface('channel', '<channelId>');
__xyne.context;                              // what the app currently sees
```

Every change is written to the URL, so you can bookmark a surface, share it with a teammate, or open it from an end-to-end test. When only an id is given, the channel name is filled in once the channel list loads.

When the dev server starts, the surface is chosen in this order:

1. `?xyne_surface=` / `?xyne_channel=` in the URL
2. the last choice you made in this browser
3. `devSurface` / `devChannelId` in `xyne.json`
4. `standalone`

Set `devSurface` to the place your app is really meant for. It's committed with the project, so anyone who clones the app starts in the right mode:

```json
{ "title": "Channel Stats", "entry": "/App.tsx", "devSurface": "channel", "devChannelId": "<channelId>" }
```

### When it's published

`lib/xyne-context.ts` is dev-only. `push` and `publish` never upload it, and Spaces puts its own implementation at the same path, which reads where the app is really mounted. Your `import { useXyneContext } from './lib/xyne-context'` stays the same, and none of the switcher code ships. `devSurface` and `devChannelId` are never uploaded either. Don't put app logic in `lib/xyne-context.ts`: your changes won't exist in the published app.

To test the real thing, publish and open the app from each place: add it to the toolbar, the Inbox menubar and a channel's tabs.

## Host

Every command talks to one host. Precedence, highest first:

1. `--url <host>` on the command
2. `XYNE_BASE_URL` in the environment
3. the saved default (`spaces config set url <host>` → `~/.spaces/config.json`)
4. `https://spaces.xyne.juspay.net`

```bash
spaces config set url https://spaces.xyne.juspay.net   # point at a deployment, once
```

## Auth model

- **`token`** reads the Spaces session from the browser you're already signed into (Chrome / Brave / Edge / Arc) and writes it to `.env` for your app's SDK. Quit the browser first if it reports a stale session.
- **`app` commands** authenticate the same way — your Spaces browser session — so one login covers everything. `XYNE_CLAW_TOKEN` overrides with a bearer token for CI.

You can only push/publish apps you own; secrets and database files are never uploaded.
